"""Bounded S02 AgentCore Harness exercise for issue #493.

The only tool implementation is a local lookup in SYNTHETIC_RECORDS. It never
executes a command, opens a socket, reads a file, or calls another AWS service.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import time
import uuid
from pathlib import Path
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError


REGION = "ap-northeast-1"
MODEL_ID = "amazon.nova-lite-v1:0"
HARNESS_NAME = "UdemySZeroTwoIssueFourNineThree"
ROLE_NAME = "UdemySZeroTwoIssueFourNineThreeRole"
POLICY_NAME = "InvokeTokyoNovaLiteAndTaskTelemetry"
TASK_TAG_KEY = "Exercise"
TASK_TAG_VALUE = "UdemySZeroTwoIssueFourNineThree"
TOOL_NAME = "lookup_example_record"
TOOL_SELECTOR = "@lookup_example_record"
RECORD_ID = "CASE-042"
QUESTION = (
    "教材用の架空記録 CASE-042 を確認し、記録されているHTTP状態と"
    "次の確認項目を答えてください。記録が確認できなければ不明としてください。"
)
SYSTEM_PROMPT = (
    "教材用の架空記録を調べるアシスタントです。"
    "質問がCASE-042の状態または次の確認項目を尋ねる場合は"
    "lookup_example_recordを一度だけ呼び出してください。"
    "返された記録にある事実だけを答え、原因を推測しないでください。"
)
TOOL_CONFIG = {
    "type": "inline_function",
    "name": TOOL_NAME,
    "config": {
        "inlineFunction": {
            "description": "指定した架空の教材記録を1件だけ読み取ります。",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "record_id": {
                        "type": "string",
                        "enum": [RECORD_ID],
                        "description": "教材用の架空記録ID。CASE-042のみ対応。",
                    }
                },
                "required": ["record_id"],
                "additionalProperties": False,
            },
        }
    },
}
ALLOWED_TOOLS = [TOOL_SELECTOR]
SYNTHETIC_RECORDS = {
    RECORD_ID: {
        "record_id": RECORD_ID,
        "http_status": 503,
        "next_check": "同じ時間帯のアプリケーションログで依存先の応答を確認する",
    }
}
MODEL_CONFIG = {
    "bedrockModelConfig": {
        "modelId": MODEL_ID,
        "apiFormat": "converse_stream",
        "maxTokens": 256,
        "temperature": 0,
    }
}
TAGS = {"Purpose": "S02SyntheticExercise"}
STATE_PATH = Path(__file__).resolve().with_name("exercise-state.json")
CREATE_TOKEN_PATH = Path(__file__).resolve().with_name(".harness-create-token")
DELETE_TOKEN_PATH = Path(__file__).resolve().with_name(".harness-delete-token")
TRUST_TEMPLATE_PATH = Path(__file__).resolve().with_name("execution-role-trust.json")
POLICY_TEMPLATE_PATH = Path(__file__).resolve().with_name("execution-role-policy.json")
MAX_WAIT_SECONDS = 300
MAX_LOG_GROUPS = 20


class ExerciseError(RuntimeError):
    """A bounded, user-actionable stop condition."""


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _fingerprint(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ExerciseError(f"Required local file is missing: {path.name}") from exc
    except json.JSONDecodeError as exc:
        raise ExerciseError(f"Local JSON is invalid: {path.name}") from exc
    if not isinstance(value, dict):
        raise ExerciseError(f"Expected a JSON object in {path.name}")
    return value


def _save_state(state: dict[str, Any]) -> None:
    temporary = STATE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(STATE_PATH)


def _load_state() -> dict[str, Any]:
    if not STATE_PATH.exists():
        return {}
    return _load_json(STATE_PATH)


def _read_or_create_token(path: Path) -> str:
    if path.exists():
        token = path.read_text(encoding="utf-8").strip()
        if re.fullmatch(r"[0-9a-f]{33}", token):
            return token
        raise ExerciseError(f"The local idempotency token in {path.name} is invalid")
    token = uuid.uuid4().hex + "0"
    path.write_text(token + "\n", encoding="utf-8")
    return token


def _clients() -> tuple[Any, Any, Any, Any, Any, Any]:
    # One attempt per API call; ambiguous mutations are never retried implicitly.
    config = Config(
        connect_timeout=10,
        read_timeout=120,
        retries={"total_max_attempts": 1},
    )
    session = boto3.Session(region_name=REGION)
    sts = session.client("sts", config=config)
    iam = session.client("iam", config=config)
    control = session.client("bedrock-agentcore-control", config=config)
    runtime = session.client("bedrock-agentcore", config=config)
    bedrock = session.client("bedrock-runtime", config=config)
    logs = session.client("logs", config=config)
    return sts, iam, control, runtime, bedrock, logs


def _check_sdk(sts: Any, iam: Any, control: Any, runtime: Any, bedrock: Any, logs: Any) -> None:
    required = {
        "bedrock-agentcore-control": (control, ("CreateHarness", "GetHarness", "ListHarnesses", "DeleteHarness")),
        "bedrock-agentcore": (runtime, ("InvokeHarness",)),
        "bedrock-runtime": (bedrock, ("Converse",)),
        "iam": (iam, ("GetRole", "CreateRole", "PutRolePolicy", "DeleteRolePolicy", "DeleteRole", "ListAttachedRolePolicies", "ListRolePolicies", "GetRolePolicy", "ListRoleTags")),
        "logs": (logs, ("DescribeLogGroups", "DeleteLogGroup")),
        "sts": (sts, ("GetCallerIdentity",)),
    }
    missing: list[str] = []
    for service_name, (client, operation_names) in required.items():
        available = set(client.meta.service_model.operation_names)
        missing.extend(f"{service_name}.{name}" for name in operation_names if name not in available)
    if "CreateHarness" in control.meta.service_model.operation_names:
        create_shape = control.meta.service_model.operation_model("CreateHarness").input_shape
        if not {"model", "tools", "allowedTools", "memory", "clientToken"}.issubset(create_shape.members):
            missing.append("CreateHarness model/tools/allowedTools/memory/clientToken fields")
    if "InvokeHarness" in runtime.meta.service_model.operation_names:
        invoke_shape = runtime.meta.service_model.operation_model("InvokeHarness").input_shape
        if not {"runtimeSessionId", "messages", "tools"}.issubset(invoke_shape.members):
            missing.append("InvokeHarness runtimeSessionId/messages/tools fields")
    if missing:
        raise ExerciseError(
            "The preinstalled boto3/botocore model is too old for this exercise; "
            "stop before AWS changes and use an approved SDK version. Missing: " + ", ".join(missing)
        )


def _identity(args: argparse.Namespace, clients: tuple[Any, ...]) -> tuple[str, str]:
    sts = clients[0]
    if not re.fullmatch(r"\d{12}", args.expected_account):
        raise ExerciseError("--expected-account must be exactly 12 digits")
    if not args.expected_caller_arn.startswith("arn:aws:sts::"):
        raise ExerciseError("--expected-caller-arn must be the exact STS caller ARN from preflight")
    identity = sts.get_caller_identity()
    actual_account = identity["Account"]
    actual_arn = identity["Arn"]
    if actual_account != args.expected_account or actual_arn != args.expected_caller_arn:
        raise ExerciseError(
            "AWS caller identity does not exactly match the preflight values; no change was made"
        )
    return actual_account, actual_arn


def _bind_state(state: dict[str, Any], account_id: str) -> dict[str, Any]:
    if state and (state.get("account_id") != account_id or state.get("region") != REGION):
        raise ExerciseError("Local state belongs to a different AWS account or Region; no change was made")
    state["account_id"] = account_id
    state["region"] = REGION
    return state


def _verify_role_arn(account_id: str, role_arn: str) -> None:
    expected = f"arn:aws:iam::{account_id}:role/{ROLE_NAME}"
    if role_arn != expected:
        raise ExerciseError("Role ARN must be the newly created task role in the preflight account")


def _render_template(path: Path, account_id: str) -> dict[str, Any]:
    raw = path.read_text(encoding="utf-8")
    rendered = raw.replace("__ACCOUNT_ID__", account_id)
    value = json.loads(rendered)
    if "__ACCOUNT_ID__" in _canonical(value):
        raise ExerciseError(f"Unresolved account placeholder in {path.name}")
    return value


def _role_documents(account_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    trust = _render_template(TRUST_TEMPLATE_PATH, account_id)
    permissions = _render_template(POLICY_TEMPLATE_PATH, account_id)
    return trust, permissions


def _policy_matches(actual: Any, expected: dict[str, Any]) -> bool:
    if isinstance(actual, str):
        actual = json.loads(actual)
    return _canonical(actual) == _canonical(expected)


def _provider_code(exc: ClientError) -> str:
    code = str(exc.response.get("Error", {}).get("Code", "AWSClientError"))
    return code if re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", code) else "AWSClientError"


def _verify_or_create_role(iam: Any, account_id: str) -> str:
    state = _bind_state(_load_state(), account_id)
    trust, permissions = _role_documents(account_id)
    role_arn = f"arn:aws:iam::{account_id}:role/{ROLE_NAME}"
    role_exists = True
    try:
        role_response = iam.get_role(RoleName=ROLE_NAME)
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") != "NoSuchEntity":
            raise ExerciseError(f"GetRole returned {_provider_code(exc)}; stop and inspect AWS access") from exc
        role_exists = False
        role_response = None

    if not role_exists:
        state["role_setup_started"] = True
        _save_state(state)
        try:
            iam.create_role(
                RoleName=ROLE_NAME,
                Description="Temporary S02 synthetic read-tool exercise role",
                AssumeRolePolicyDocument=json.dumps(trust),
                Tags=[
                    {"Key": TASK_TAG_KEY, "Value": TASK_TAG_VALUE},
                    {"Key": "Purpose", "Value": "S02SyntheticExercise"},
                ],
            )
        except ClientError as exc:
            if exc.response.get("Error", {}).get("Code") != "EntityAlreadyExists":
                raise ExerciseError(
                    f"CreateRole returned {_provider_code(exc)}; read the role and tags before any retry"
                ) from exc
        try:
            role_response = iam.get_role(RoleName=ROLE_NAME)
        except ClientError as exc:
            raise ExerciseError(f"GetRole returned {_provider_code(exc)} after CreateRole; inspect before continuing") from exc

    role = role_response["Role"]
    tags = {item["Key"]: item["Value"] for item in iam.list_role_tags(RoleName=ROLE_NAME).get("Tags", [])}
    if tags.get(TASK_TAG_KEY) != TASK_TAG_VALUE:
        raise ExerciseError("A role with the reserved name exists without this task tag; it was not changed")
    if role.get("Arn") != role_arn or not _policy_matches(role.get("AssumeRolePolicyDocument"), trust):
        raise ExerciseError("The task role ARN or trust policy differs from the expected document")

    attached = iam.list_attached_role_policies(RoleName=ROLE_NAME).get("AttachedPolicies", [])
    if attached:
        raise ExerciseError("The dedicated role has attached managed policies; it was not changed")
    inline_names = iam.list_role_policies(RoleName=ROLE_NAME).get("PolicyNames", [])
    if inline_names not in ([], [POLICY_NAME]):
        raise ExerciseError("The dedicated role has unexpected inline policies; it was not changed")
    if inline_names == [POLICY_NAME]:
        current = iam.get_role_policy(RoleName=ROLE_NAME, PolicyName=POLICY_NAME)["PolicyDocument"]
        if not _policy_matches(current, permissions):
            raise ExerciseError("The task role policy differs from the exact expected policy")
    else:
        try:
            iam.put_role_policy(
                RoleName=ROLE_NAME,
                PolicyName=POLICY_NAME,
                PolicyDocument=json.dumps(permissions),
            )
        except ClientError as exc:
            raise ExerciseError(f"PutRolePolicy returned {_provider_code(exc)}; read it before retrying") from exc

    state["role_setup_started"] = True
    state["role_prepared"] = True
    _save_state(state)
    return role_arn


def _verify_role(iam: Any, account_id: str, role_arn: str, allow_missing_policy: bool = False) -> None:
    _verify_role_arn(account_id, role_arn)
    trust, permissions = _role_documents(account_id)
    try:
        role = iam.get_role(RoleName=ROLE_NAME)["Role"]
        policy_names = iam.list_role_policies(RoleName=ROLE_NAME).get("PolicyNames", [])
        attached = iam.list_attached_role_policies(RoleName=ROLE_NAME).get("AttachedPolicies", [])
    except ClientError as exc:
        raise ExerciseError("Could not read back the dedicated role configuration") from exc
    tags = {item["Key"]: item["Value"] for item in iam.list_role_tags(RoleName=ROLE_NAME).get("Tags", [])}
    if tags.get(TASK_TAG_KEY) != TASK_TAG_VALUE:
        raise ExerciseError("Dedicated role tag does not match this exercise")
    if not _policy_matches(role.get("AssumeRolePolicyDocument"), trust):
        raise ExerciseError("Dedicated role trust policy does not match the exercise template")
    allowed_inline_names = ([], [POLICY_NAME]) if allow_missing_policy else ([POLICY_NAME],)
    if attached or policy_names not in allowed_inline_names:
        raise ExerciseError("Dedicated role has unexpected attached or inline policies")
    if policy_names:
        current = iam.get_role_policy(RoleName=ROLE_NAME, PolicyName=POLICY_NAME)["PolicyDocument"]
        if not _policy_matches(current, permissions):
            raise ExerciseError("Dedicated role permission policy does not match the exercise template")


def _harness_request(role_arn: str, client_token: str) -> dict[str, Any]:
    return {
        "harnessName": HARNESS_NAME,
        "clientToken": client_token,
        "executionRoleArn": role_arn,
        "model": MODEL_CONFIG,
        "systemPrompt": [{"text": SYSTEM_PROMPT}],
        "tools": [TOOL_CONFIG],
        "allowedTools": ALLOWED_TOOLS,
        "memory": {"disabled": {}},
        "maxIterations": 2,
        "maxTokens": 256,
        "timeoutSeconds": 120,
        "tags": TAGS,
    }


def _verify_harness(harness: dict[str, Any], role_arn: str) -> None:
    model = harness.get("model", {}).get("bedrockModelConfig", {})
    memory = harness.get("memory", {})
    if harness.get("harnessName") != HARNESS_NAME:
        raise ExerciseError("Harness name does not match this exercise")
    if harness.get("executionRoleArn") != role_arn:
        raise ExerciseError("Harness uses an unexpected execution role")
    if (
        model.get("modelId") != MODEL_ID
        or model.get("apiFormat") != "converse_stream"
        or model.get("maxTokens") != 256
        or model.get("temperature") != 0
    ):
        raise ExerciseError("Harness model configuration differs from the expected Tokyo model")
    if harness.get("systemPrompt") != [{"text": SYSTEM_PROMPT}]:
        raise ExerciseError("Harness systemPrompt readback differs from the exercise instruction")
    if harness.get("allowedTools") != ALLOWED_TOOLS:
        raise ExerciseError("Harness allowedTools readback is not the one inline selector")
    if len(harness.get("tools", [])) != 1:
        raise ExerciseError("Harness must have exactly one configured tool")
    if _canonical(harness["tools"][0]) != _canonical(TOOL_CONFIG):
        raise ExerciseError("Harness inline tool readback differs from the approved schema")
    if not memory.get("disabled") == {} or len(memory) != 1:
        raise ExerciseError("Harness Memory is not explicitly disabled")
    if harness.get("skills"):
        raise ExerciseError("Unexpected Harness skills are configured")
    if harness.get("maxIterations") != 2 or harness.get("maxTokens") != 256 or harness.get("timeoutSeconds") != 120:
        raise ExerciseError("Harness execution bounds differ from the exercise settings")


def _verify_harness_owner(harness: dict[str, Any], harness_id: str, role_arn: str, account_id: str) -> None:
    expected_arn_prefix = f"arn:aws:bedrock-agentcore:{REGION}:{account_id}:harness/"
    if harness.get("harnessId") != harness_id or harness.get("harnessName") != HARNESS_NAME:
        raise ExerciseError("Harness identity does not match the task-owned resource")
    if harness.get("executionRoleArn") != role_arn:
        raise ExerciseError("Harness does not use the dedicated task role")
    if not str(harness.get("arn", "")).startswith(expected_arn_prefix):
        raise ExerciseError("Harness ARN is outside the verified account and Tokyo Region")


def _record_runtime_identity(state: dict[str, Any], harness: dict[str, Any]) -> None:
    environment = harness.get("environment", {}).get("agentCoreRuntimeEnvironment", {})
    runtime_id = environment.get("agentRuntimeId")
    if runtime_id is None:
        return
    expected_prefix = f"harness_{HARNESS_NAME}-"
    if not isinstance(runtime_id, str) or not runtime_id.startswith(expected_prefix):
        raise ExerciseError("Harness readback has an unexpected underlying Runtime ID")
    state["runtime_id"] = runtime_id


def _print_config_readback(harness: dict[str, Any]) -> None:
    model = harness["model"]["bedrockModelConfig"]
    print(f"Harness readback: status={harness.get('status')}, modelId={model['modelId']}, apiFormat={model['apiFormat']}")
    print(f"allowedTools={json.dumps(harness['allowedTools'])}; Memory=disabled; tool={harness['tools'][0]['name']}")
    print("Readback systemPrompt:")
    print(harness["systemPrompt"][0]["text"])


def _list_harnesses(control: Any) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    token: str | None = None
    page_count = 0
    while True:
        page_count += 1
        if page_count > 10:
            raise ExerciseError("Harness listing exceeded the 10-page safety bound")
        kwargs: dict[str, Any] = {"maxResults": 100}
        if token:
            kwargs["nextToken"] = token
        page = control.list_harnesses(**kwargs)
        items.extend(page.get("harnesses", []))
        token = page.get("nextToken")
        if not token:
            return items


def _list_log_groups(logs: Any, prefix: str) -> list[str]:
    names: list[str] = []
    token: str | None = None
    page_count = 0
    while True:
        page_count += 1
        if page_count > 5:
            raise ExerciseError("Log group listing exceeded the 5-page safety bound")
        kwargs: dict[str, Any] = {"logGroupNamePrefix": prefix, "limit": 50}
        if token:
            kwargs["nextToken"] = token
        page = logs.describe_log_groups(**kwargs)
        for item in page.get("logGroups", []):
            name = item.get("logGroupName", "")
            if not name.startswith(prefix):
                raise ExerciseError("CloudWatch returned a log group outside the requested prefix")
            names.append(name)
            if len(names) > MAX_LOG_GROUPS:
                raise ExerciseError("More than 20 groups match this exact Harness runtime prefix")
        token = page.get("nextToken")
        if not token:
            return names


def _runtime_log_prefix(runtime_id: str) -> str:
    if not runtime_id.startswith(f"harness_{HARNESS_NAME}-"):
        raise ExerciseError("Underlying Runtime ID is not bound to the task Harness name")
    return f"/aws/bedrock-agentcore/runtimes/{runtime_id}-"


def _get_harness(control: Any, harness_id: str, role_arn: str, account_id: str) -> dict[str, Any]:
    try:
        harness = control.get_harness(harnessId=harness_id)["harness"]
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code")
        if code == "ResourceNotFoundException":
            raise ExerciseError("Harness ID is not present in this account and Region") from exc
        raise ExerciseError(f"GetHarness returned {_provider_code(exc)}") from exc
    _verify_harness_owner(harness, harness_id, role_arn, account_id)
    _verify_harness(harness, role_arn)
    return harness


def _wait_ready(control: Any, harness_id: str, role_arn: str, account_id: str) -> dict[str, Any]:
    deadline = time.monotonic() + MAX_WAIT_SECONDS
    while True:
        harness = _get_harness(control, harness_id, role_arn, account_id)
        status = harness.get("status")
        if status == "READY":
            return harness
        if status in {"CREATE_FAILED", "UPDATE_FAILED", "DELETE_FAILED"}:
            raise ExerciseError(f"Harness entered terminal status {status}; preserve it for review")
        if status == "DELETING":
            raise ExerciseError("Harness is already deleting; do not create or invoke another one")
        if time.monotonic() >= deadline:
            raise ExerciseError("Harness did not become READY within 5 minutes; stop and record status")
        time.sleep(5)


def _iter_stream(response: dict[str, Any]):
    stream = response.get("stream")
    if stream is None:
        raise ExerciseError("InvokeHarness returned no event stream")
    for event in stream:
        if not isinstance(event, dict):
            raise ExerciseError("InvokeHarness returned an unknown stream event")
        error_keys = [key for key in event if key.endswith("Exception") or key.endswith("Error")]
        if error_keys:
            key = error_keys[0]
            detail = event.get(key)
            provider_code = detail.get("code", key) if isinstance(detail, dict) else key
            safe_code = provider_code if isinstance(provider_code, str) and re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", provider_code) else key
            message = detail.get("message") if isinstance(detail, dict) else None
            safe_message = ""
            if isinstance(message, str):
                message = " ".join(message.split())
                sensitive_marker = re.search(
                    r"(?i)(authorization|credential|access.?key|secret.?access.?key|secret.?key|session.?token|security.?token|password|cookie|headers?|environment|bearer)",
                    message,
                )
                if not sensitive_marker:
                    message = re.sub(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b", "[redacted]", message)
                    message = re.sub(r"\bBearer\s+\S+", "Bearer [redacted]", message, flags=re.IGNORECASE)
                    safe_message = message[:240]
            metadata = response.get("ResponseMetadata", {})
            request_id = metadata.get("RequestId") if isinstance(metadata, dict) else None
            safe_request_id = request_id if isinstance(request_id, str) and re.fullmatch(r"[A-Za-z0-9-]{1,128}", request_id) else None
            diagnostic = f": {safe_message}" if safe_message else ""
            request = f" (requestId={safe_request_id})" if safe_request_id else ""
            raise ExerciseError(f"InvokeHarness stream event {safe_code}{diagnostic}{request}; do not retry automatically")
        yield event


def _collect_handoff(response: dict[str, Any]) -> tuple[str, str, dict[str, Any]]:
    tool_events: list[dict[str, Any]] = []
    selected_index: int | None = None
    input_parts: list[str] = []
    stopped_indexes: set[int] = set()
    stop_reason: str | None = None
    for event in _iter_stream(response):
        start_block = event.get("contentBlockStart")
        if start_block:
            start = start_block.get("start", {})
            if "toolUse" in start:
                tool_events.append(start["toolUse"])
                selected_index = start_block.get("contentBlockIndex")
        stop_block = event.get("contentBlockStop")
        if stop_block:
            index = stop_block.get("contentBlockIndex")
            if isinstance(index, int):
                stopped_indexes.add(index)
        delta_block = event.get("contentBlockDelta")
        if delta_block and delta_block.get("contentBlockIndex") == selected_index:
            delta = delta_block.get("delta", {})
            if "toolUse" in delta:
                value = delta["toolUse"].get("input", "")
                if not isinstance(value, str):
                    raise ExerciseError("Tool input arrived in an unexpected format")
                input_parts.append(value)
        if "messageStop" in event:
            stop_reason = event["messageStop"].get("stopReason")
    if stop_reason != "tool_use" or len(tool_events) != 1 or selected_index not in stopped_indexes:
        raise ExerciseError("Expected exactly one tool handoff; no tool was executed")
    tool = tool_events[0]
    if tool.get("name") != TOOL_NAME:
        raise ExerciseError("Model proposed an unexpected tool; it was not executed")
    if tool.get("type") not in (None, "tool_use"):
        raise ExerciseError("Model proposed a non-inline tool; it was not executed")
    tool_use_id = tool.get("toolUseId")
    if not isinstance(tool_use_id, str) or not tool_use_id:
        raise ExerciseError("Tool handoff has no valid toolUseId")
    raw_input = "".join(input_parts)
    try:
        arguments = json.loads(raw_input)
    except json.JSONDecodeError as exc:
        raise ExerciseError("Model proposed malformed tool input; it was not executed") from exc
    if not isinstance(arguments, dict) or set(arguments) != {"record_id"}:
        raise ExerciseError("Tool input has unexpected fields; it was not executed")
    if arguments["record_id"] != RECORD_ID:
        raise ExerciseError("Tool input requested an unexpected record; it was not executed")
    return tool_use_id, raw_input, arguments


def _read_synthetic_record(arguments: dict[str, Any]) -> dict[str, Any]:
    if set(arguments) != {"record_id"} or arguments["record_id"] != RECORD_ID:
        raise ExerciseError("Read-only lookup rejected unexpected input")
    record = SYNTHETIC_RECORDS.get(arguments["record_id"])
    if record is None:
        raise ExerciseError("No synthetic record exists for that ID")
    return dict(record)


def _collect_final_text(response: dict[str, Any]) -> tuple[str, str | None]:
    text_parts: list[str] = []
    stop_reason: str | None = None
    for event in _iter_stream(response):
        block = event.get("contentBlockStart", {})
        if "toolUse" in block.get("start", {}):
            raise ExerciseError("Second Harness response requested another tool; no further tool was executed")
        delta_block = event.get("contentBlockDelta")
        if delta_block:
            delta = delta_block.get("delta", {})
            if "toolUse" in delta:
                raise ExerciseError("Second Harness response requested another tool; no further tool was executed")
            if isinstance(delta.get("text"), str):
                text_parts.append(delta["text"])
        if "messageStop" in event:
            stop_reason = event["messageStop"].get("stopReason")
    if stop_reason != "end_turn":
        raise ExerciseError(f"Harness did not finish normally (stopReason={stop_reason!r})")
    final_text = "".join(text_parts).strip()
    if not final_text:
        raise ExerciseError("Harness returned no final text")
    return final_text, stop_reason


def _require_state(state: dict[str, Any], key: str, description: str) -> Any:
    value = state.get(key)
    if value is None:
        raise ExerciseError(f"No saved {description}; run the preceding exercise step first")
    return value


def _do_preflight(args: argparse.Namespace, clients: tuple[Any, ...]) -> None:
    account_id, _ = _identity(args, clients)
    print(f"Preflight matched the supplied caller identity; Region={REGION}; account ending={account_id[-4:]}")
    print("SDK service operations and required request fields are available.")


def _do_baseline(args: argparse.Namespace, clients: tuple[Any, ...]) -> None:
    account_id, _ = _identity(args, clients)
    state = _bind_state(_load_state(), account_id)
    if state.get("baseline") in {"started", "complete"}:
        raise ExerciseError("The single baseline call was already started; do not repeat it")
    state["baseline"] = "started"
    _save_state(state)
    bedrock = clients[4]
    try:
        response = bedrock.converse(
            modelId=MODEL_ID,
            messages=[{"role": "user", "content": [{"text": QUESTION}]}],
            inferenceConfig={"maxTokens": 256, "temperature": 0},
        )
    except ClientError as exc:
        raise ExerciseError(f"Converse returned {_provider_code(exc)}; do not retry without state/cost review") from exc
    parts = [item["text"] for item in response.get("output", {}).get("message", {}).get("content", []) if "text" in item]
    answer = "\n".join(parts).strip()
    if not answer:
        raise ExerciseError("Baseline response did not contain text")
    state["baseline"] = "complete"
    state["model_id"] = MODEL_ID
    state["region"] = REGION
    _save_state(state)
    print(f"Model: {MODEL_ID} ({REGION})")
    print(f"Question: {QUESTION}")
    print("Direct model response:")
    print(answer)
    print("The response is model output; it is not evidence that a tool read the record.")


def _do_prepare_role(args: argparse.Namespace, clients: tuple[Any, ...]) -> None:
    account_id, _ = _identity(args, clients)
    iam = clients[1]
    role_arn = _verify_or_create_role(iam, account_id)
    _verify_role(iam, account_id, role_arn)
    print(f"Readback matched the dedicated role and inline policy: {ROLE_NAME} / {POLICY_NAME}")


def _harness_payload_fingerprint(role_arn: str) -> str:
    token = "fingerprint-placeholder"
    return _fingerprint(_harness_request(role_arn, token))


def _do_create(args: argparse.Namespace, clients: tuple[Any, ...]) -> None:
    account_id, _ = _identity(args, clients)
    state = _bind_state(_load_state(), account_id)
    if state.get("baseline") != "complete":
        raise ExerciseError("Complete the single direct-model baseline first")
    if state.get("role_prepared") is not True:
        raise ExerciseError("Prepare and read back the dedicated execution role first")
    role_arn = f"arn:aws:iam::{account_id}:role/{ROLE_NAME}"
    _verify_role(clients[1], account_id, role_arn)
    payload_hash = _harness_payload_fingerprint(role_arn)
    control = clients[2]

    if state.get("harness_id"):
        harness = _wait_ready(control, state["harness_id"], role_arn, account_id)
        _record_runtime_identity(state, harness)
        _save_state(state)
        _print_config_readback(harness)
        return

    token = _read_or_create_token(CREATE_TOKEN_PATH)
    if state.get("create_payload_sha256") not in (None, payload_hash):
        raise ExerciseError("Saved create idempotency token belongs to different settings; stop and inspect")
    try:
        existing = _list_harnesses(control)
    except ClientError as exc:
        raise ExerciseError("Could not check for a Harness name collision; no create call was sent") from exc
    matches = [item for item in existing if item.get("harnessName") == HARNESS_NAME]
    if matches:
        if state.get("create_status") != "started" or not state.get("creation_absence_confirmed"):
            raise ExerciseError("A Harness with the reserved name exists without task creation evidence; it was not changed")
        if len(matches) != 1:
            raise ExerciseError("Multiple Harnesses match the reserved name; stop for ownership review")
        recovered_id = matches[0]["harnessId"]
        recovered = control.get_harness(harnessId=recovered_id)["harness"]
        _verify_harness_owner(recovered, recovered_id, role_arn, account_id)
        state["harness_id"] = recovered_id
        state["create_status"] = "accepted"
        _record_runtime_identity(state, recovered)
        _save_state(state)
        ready = _wait_ready(control, recovered_id, role_arn, account_id)
        state["create_status"] = "ready"
        _record_runtime_identity(state, ready)
        _save_state(state)
        _print_config_readback(ready)
        return
    if state.get("create_status") == "started" and not args.resume_idempotent:
        raise ExerciseError("CreateHarness outcome is uncertain; review current state before --resume-idempotent")

    log_prefix = f"/aws/bedrock-agentcore/runtimes/harness_{HARNESS_NAME}-"
    previous_groups = _list_log_groups(clients[5], log_prefix)
    if state.get("create_status") is None and previous_groups:
        raise ExerciseError("A task-named runtime log group predates this run; no Harness was created")
    state["preexisting_log_groups"] = previous_groups if state.get("create_status") is None else state.get("preexisting_log_groups", [])
    state["creation_absence_confirmed"] = True

    state["create_payload_sha256"] = payload_hash
    state["create_status"] = "started"
    _save_state(state)
    try:
        response = control.create_harness(**_harness_request(role_arn, token))
    except ClientError as exc:
        raise ExerciseError(
            f"CreateHarness returned {_provider_code(exc)}. Do not retry automatically; inspect ListHarnesses first."
        ) from exc
    harness = response["harness"]
    harness_id = harness.get("harnessId")
    if not harness_id:
        raise ExerciseError("CreateHarness returned no HarnessId; inspect ListHarnesses before any retry")
    state["harness_id"] = harness_id
    state["create_status"] = "accepted"
    _save_state(state)
    _verify_harness_owner(harness, harness_id, role_arn, account_id)
    _record_runtime_identity(state, harness)
    ready = _wait_ready(control, harness_id, role_arn, account_id)
    state["create_status"] = "ready"
    _record_runtime_identity(state, ready)
    _save_state(state)
    _print_config_readback(ready)


def _do_invoke(args: argparse.Namespace, clients: tuple[Any, ...]) -> None:
    account_id, _ = _identity(args, clients)
    state = _bind_state(_load_state(), account_id)
    if state.get("create_status") != "ready":
        raise ExerciseError("Create and read back the dedicated Harness first")
    run_state = state.get("harness_run")
    if run_state:
        raise ExerciseError(
            "A Harness invocation has already started. Inspect the saved stage and service records; do not repeat calls."
        )
    harness_id = _require_state(state, "harness_id", "Harness ID")
    role_arn = f"arn:aws:iam::{account_id}:role/{ROLE_NAME}"
    harness = _wait_ready(clients[2], harness_id, role_arn, account_id)
    harness_arn = harness["arn"]
    session_id = uuid.uuid4().hex + "0"  # RuntimeSessionId requires at least 33 characters.
    state["harness_run"] = {"stage": "invoke_started", "session_id": session_id}
    _save_state(state)

    request = {
        "harnessArn": harness_arn,
        "runtimeSessionId": session_id,
        "messages": [{"role": "user", "content": [{"text": QUESTION}]}],
        "maxIterations": 2,
        "maxTokens": 256,
        "timeoutSeconds": 120,
    }
    try:
        first_response = clients[3].invoke_harness(**request)
    except ClientError as exc:
        raise ExerciseError(f"InvokeHarness first call returned {_provider_code(exc)}; inspect before another invocation") from exc
    tool_use_id, raw_input, arguments = _collect_handoff(first_response)
    state["harness_run"].update(
        {"stage": "tool_pending", "tool_use_id": tool_use_id, "tool_input": raw_input}
    )
    _save_state(state)
    record = _read_synthetic_record(arguments)
    state["harness_run"].update({"stage": "result_submit_started", "tool_result": record})
    _save_state(state)

    follow_up = {
        "harnessArn": harness_arn,
        "runtimeSessionId": session_id,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "toolResult": {
                            "toolUseId": tool_use_id,
                            "content": [{"text": json.dumps(record, ensure_ascii=False, sort_keys=True)}],
                            "status": "success",
                        }
                    }
                ],
            }
        ],
    }
    try:
        second_response = clients[3].invoke_harness(**follow_up)
    except ClientError as exc:
        raise ExerciseError(f"InvokeHarness follow-up returned {_provider_code(exc)}; do not resubmit the result") from exc
    final_text, _ = _collect_final_text(second_response)
    state["harness_run"]["stage"] = "complete"
    _save_state(state)
    print(f"Model: {MODEL_ID} ({REGION})")
    print(f"Question: {QUESTION}")
    print(f"Tool: {TOOL_NAME}")
    print(f"Validated tool input: {raw_input}")
    print("Synthetic tool result:")
    print(json.dumps(record, ensure_ascii=False, sort_keys=True))
    print("Harness final response:")
    print(final_text)
    print("The tool result was returned in the same runtimeSessionId; no other tool was dispatched.")


def _find_task_harness(control: Any, account_id: str, role_arn: str) -> dict[str, Any] | None:
    matches = [item for item in _list_harnesses(control) if item.get("harnessName") == HARNESS_NAME]
    if not matches:
        return None
    if len(matches) != 1:
        raise ExerciseError("Multiple Harnesses match the reserved name; stop for ownership review")
    harness = control.get_harness(harnessId=matches[0]["harnessId"])["harness"]
    _verify_harness_owner(harness, matches[0]["harnessId"], role_arn, account_id)
    return harness


def _delete_owned_role(iam: Any, account_id: str, role_arn: str) -> None:
    try:
        iam.get_role(RoleName=ROLE_NAME)
    except ClientError as exc:
        if _provider_code(exc) == "NoSuchEntity":
            return
        raise ExerciseError(f"GetRole returned {_provider_code(exc)}; role cleanup stopped") from exc
    _verify_role(iam, account_id, role_arn, allow_missing_policy=True)
    policy_names = iam.list_role_policies(RoleName=ROLE_NAME).get("PolicyNames", [])
    if policy_names:
        iam.delete_role_policy(RoleName=ROLE_NAME, PolicyName=POLICY_NAME)
    iam.delete_role(RoleName=ROLE_NAME)
    try:
        iam.get_role(RoleName=ROLE_NAME)
    except ClientError as exc:
        if _provider_code(exc) == "NoSuchEntity":
            return
        raise ExerciseError(f"GetRole readback returned {_provider_code(exc)} after delete") from exc
    raise ExerciseError("Task role still exists after delete; do not repeat without inspection")


def _do_cleanup(args: argparse.Namespace, clients: tuple[Any, ...]) -> None:
    account_id, _ = _identity(args, clients)
    state = _bind_state(_load_state(), account_id)
    role_arn = f"arn:aws:iam::{account_id}:role/{ROLE_NAME}"
    control, iam, logs = clients[2], clients[1], clients[5]
    harness_id = state.get("harness_id")
    harness: dict[str, Any] | None = None

    if harness_id:
        try:
            harness = control.get_harness(harnessId=harness_id)["harness"]
        except ClientError as exc:
            if _provider_code(exc) != "ResourceNotFoundException":
                raise ExerciseError(f"GetHarness returned {_provider_code(exc)}; no cleanup was attempted") from exc
    elif state.get("create_status") == "started" and state.get("creation_absence_confirmed"):
        harness = _find_task_harness(control, account_id, role_arn)
        if harness:
            harness_id = harness["harnessId"]
            state["harness_id"] = harness_id
            state["create_status"] = "accepted"
            _record_runtime_identity(state, harness)
            _save_state(state)
        elif not args.confirm_no_harness:
            raise ExerciseError(
                "CreateHarness acceptance is uncertain. Review ListHarnesses, then use --confirm-no-harness only if absent."
            )

    if harness is not None:
        _verify_harness_owner(harness, harness_id, role_arn, account_id)
        _record_runtime_identity(state, harness)
        runtime_id = state.get("runtime_id")
        if state.get("preexisting_log_groups"):
            raise ExerciseError("A matching runtime log group existed before creation; cleanup needs human review")
        _save_state(state)
        if harness.get("status") != "DELETING":
            if state.get("harness_delete_started") and not args.resume_delete:
                raise ExerciseError("DeleteHarness outcome is uncertain; review state before --resume-delete")
            token = _read_or_create_token(DELETE_TOKEN_PATH)
            state["harness_delete_started"] = True
            _save_state(state)
            try:
                control.delete_harness(
                    harnessId=harness_id,
                    clientToken=token,
                    deleteManagedMemory=True,
                )
            except ClientError as exc:
                raise ExerciseError(f"DeleteHarness returned {_provider_code(exc)}; preserve state and inspect") from exc
            state["harness_delete_accepted"] = True
            _save_state(state)

    if harness_id:
        deadline = time.monotonic() + MAX_WAIT_SECONDS
        while True:
            try:
                control.get_harness(harnessId=harness_id)
            except ClientError as exc:
                if _provider_code(exc) == "ResourceNotFoundException":
                    break
                raise ExerciseError(f"GetHarness returned {_provider_code(exc)}; retain role and logs") from exc
            if time.monotonic() >= deadline:
                raise ExerciseError("Harness deletion did not finish within 5 minutes; retain remaining resources")
            time.sleep(5)
        state["harness_deleted"] = True
        _save_state(state)
    elif state.get("create_status") == "started" and not args.confirm_no_harness:
        raise ExerciseError("Harness acceptance is uncertain; the role was retained")

    if not (state.get("role_setup_started") or state.get("role_prepared") or state.get("creation_absence_confirmed")):
        raise ExerciseError("No task-owned setup evidence is recorded; no IAM role was deleted")
    runtime_id = state.get("runtime_id")
    if runtime_id:
        prefix = _runtime_log_prefix(runtime_id)
        log_names = _list_log_groups(logs, prefix)
        prior = set(state.get("preexisting_log_groups", []))
        if any(name in prior for name in log_names):
            raise ExerciseError("A runtime log group predates this resource; no logs were deleted")
        for name in log_names:
            logs.delete_log_group(logGroupName=name)
    else:
        broad_prefix = f"/aws/bedrock-agentcore/runtimes/harness_{HARNESS_NAME}-"
        unknown_logs = _list_log_groups(logs, broad_prefix)
        if unknown_logs:
            print("RuntimeId was unavailable. These task-prefix groups were retained for owner verification:")
            for name in unknown_logs:
                print(name)
            _delete_owned_role(iam, account_id, role_arn)
            state["role_deleted"] = True
            state["log_review_required"] = True
            _save_state(state)
            return

    _delete_owned_role(iam, account_id, role_arn)
    for path in (STATE_PATH, CREATE_TOKEN_PATH, DELETE_TOKEN_PATH):
        path.unlink(missing_ok=True)
    print("The task Harness and tagged dedicated role are absent; only logs tied to its recorded Runtime ID were removed.")


def _add_identity_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--expected-account", required=True, help="12-digit account ID verified before this exercise")
    parser.add_argument("--expected-caller-arn", required=True, help="Exact STS caller ARN verified before this exercise")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Bounded synthetic AgentCore S02 exercise")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name, help_text in (
        ("preflight", "Verify identity, Region, and installed SDK models; no AWS writes"),
        ("baseline", "Make the one direct Bedrock model call"),
        ("prepare-role", "Create/read back the dedicated task role and exact inline policy"),
        ("create", "Create/read back the one dedicated Harness"),
        ("invoke", "Make one tool handoff and one same-session result continuation"),
        ("cleanup", "Delete only the task-owned Harness, role, policy, and log prefix"),
    ):
        child = subparsers.add_parser(name, help=help_text)
        _add_identity_arguments(child)
        if name == "create":
            child.add_argument("--resume-idempotent", action="store_true", help="Reuse saved CreateHarness token after read-only review")
        elif name == "cleanup":
            child.add_argument("--confirm-no-harness", action="store_true", help="Confirm exact-name absence after an unacknowledged create")
            child.add_argument("--resume-delete", action="store_true", help="Reuse saved DeleteHarness token after state review")
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        clients = _clients()
        _check_sdk(*clients)
        if args.command == "preflight":
            _do_preflight(args, clients)
        elif args.command == "baseline":
            _do_baseline(args, clients)
        elif args.command == "prepare-role":
            _do_prepare_role(args, clients)
        elif args.command == "create":
            _do_create(args, clients)
        elif args.command == "invoke":
            _do_invoke(args, clients)
        elif args.command == "cleanup":
            _do_cleanup(args, clients)
        return 0
    except ExerciseError as exc:
        print(f"STOP: {exc}", file=sys.stderr)
        return 2
    except ClientError as exc:
        code = _provider_code(exc)
        operation = str(getattr(exc, "operation_name", "AWSOperation"))
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", operation):
            operation = "AWSOperation"
        print(f"STOP: {operation} returned {code}; inspect current state before any retry", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
